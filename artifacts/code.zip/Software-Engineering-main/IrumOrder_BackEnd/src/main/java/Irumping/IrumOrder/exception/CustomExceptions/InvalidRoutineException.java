package Irumping.IrumOrder.exception.CustomExceptions;

public class InvalidRoutineException extends RuntimeException{
    public InvalidRoutineException(String message) {
        super(message);
    }
}
