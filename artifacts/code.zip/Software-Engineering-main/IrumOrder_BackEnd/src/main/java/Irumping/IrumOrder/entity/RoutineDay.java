package Irumping.IrumOrder.entity;

public enum RoutineDay {
    Mon, Tue, Wed, Thu, Fri, Sat, Sun;

}